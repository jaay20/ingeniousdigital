# Doctrine Annotations

[![Build Status](https://travis-ci.org/doctrine/annotations.png?branch=master)](https://travis-ci.org/doctrine/annotations)

Docblock Annotations Parser library (extracted from Doctrine Common).

## Changelog

### v1.1

* Add Exception when ZendOptimizer+ or Opcache is configured to drop comments
